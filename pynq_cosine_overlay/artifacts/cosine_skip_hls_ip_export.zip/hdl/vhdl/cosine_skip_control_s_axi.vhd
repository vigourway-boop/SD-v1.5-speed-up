-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
-- Tool Version Limit: 2019.12
-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;

entity cosine_skip_control_s_axi is
generic (
    C_S_AXI_ADDR_WIDTH    : INTEGER := 8;
    C_S_AXI_DATA_WIDTH    : INTEGER := 32);
port (
    ACLK                  :in   STD_LOGIC;
    ARESET                :in   STD_LOGIC;
    ACLK_EN               :in   STD_LOGIC;
    AWADDR                :in   STD_LOGIC_VECTOR(C_S_AXI_ADDR_WIDTH-1 downto 0);
    AWVALID               :in   STD_LOGIC;
    AWREADY               :out  STD_LOGIC;
    WDATA                 :in   STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH-1 downto 0);
    WSTRB                 :in   STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH/8-1 downto 0);
    WVALID                :in   STD_LOGIC;
    WREADY                :out  STD_LOGIC;
    BRESP                 :out  STD_LOGIC_VECTOR(1 downto 0);
    BVALID                :out  STD_LOGIC;
    BREADY                :in   STD_LOGIC;
    ARADDR                :in   STD_LOGIC_VECTOR(C_S_AXI_ADDR_WIDTH-1 downto 0);
    ARVALID               :in   STD_LOGIC;
    ARREADY               :out  STD_LOGIC;
    RDATA                 :out  STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH-1 downto 0);
    RRESP                 :out  STD_LOGIC_VECTOR(1 downto 0);
    RVALID                :out  STD_LOGIC;
    RREADY                :in   STD_LOGIC;
    interrupt             :out  STD_LOGIC;
    ap_start              :out  STD_LOGIC;
    ap_done               :in   STD_LOGIC;
    ap_ready              :in   STD_LOGIC;
    ap_idle               :in   STD_LOGIC;
    ap_return             :in   STD_LOGIC_VECTOR(31 downto 0);
    x                     :out  STD_LOGIC_VECTOR(63 downto 0);
    length_r              :out  STD_LOGIC_VECTOR(31 downto 0);
    step_index            :out  STD_LOGIC_VECTOR(31 downto 0);
    threshold_q15         :out  STD_LOGIC_VECTOR(31 downto 0);
    warmup_steps          :out  STD_LOGIC_VECTOR(31 downto 0);
    max_consecutive_skips :out  STD_LOGIC_VECTOR(31 downto 0);
    reset_state           :out  STD_LOGIC_VECTOR(31 downto 0);
    dot_out               :in   STD_LOGIC_VECTOR(63 downto 0);
    dot_out_ap_vld        :in   STD_LOGIC;
    norm_x_out            :in   STD_LOGIC_VECTOR(63 downto 0);
    norm_x_out_ap_vld     :in   STD_LOGIC;
    norm_y_out            :in   STD_LOGIC_VECTOR(63 downto 0);
    norm_y_out_ap_vld     :in   STD_LOGIC;
    threshold_passed_out  :in   STD_LOGIC_VECTOR(31 downto 0);
    threshold_passed_out_ap_vld :in   STD_LOGIC;
    skip_streak_out       :in   STD_LOGIC_VECTOR(31 downto 0);
    skip_streak_out_ap_vld :in   STD_LOGIC
);
end entity cosine_skip_control_s_axi;

-- ------------------------Address Info-------------------
-- 0x00 : Control signals
--        bit 0  - ap_start (Read/Write/COH)
--        bit 1  - ap_done (Read/COR)
--        bit 2  - ap_idle (Read)
--        bit 3  - ap_ready (Read/COR)
--        bit 7  - auto_restart (Read/Write)
--        bit 9  - interrupt (Read)
--        others - reserved
-- 0x04 : Global Interrupt Enable Register
--        bit 0  - Global Interrupt Enable (Read/Write)
--        others - reserved
-- 0x08 : IP Interrupt Enable Register (Read/Write)
--        bit 0 - enable ap_done interrupt (Read/Write)
--        bit 1 - enable ap_ready interrupt (Read/Write)
--        others - reserved
-- 0x0c : IP Interrupt Status Register (Read/TOW)
--        bit 0 - ap_done (Read/TOW)
--        bit 1 - ap_ready (Read/TOW)
--        others - reserved
-- 0x10 : Data signal of ap_return
--        bit 31~0 - ap_return[31:0] (Read)
-- 0x18 : Data signal of x
--        bit 31~0 - x[31:0] (Read/Write)
-- 0x1c : Data signal of x
--        bit 31~0 - x[63:32] (Read/Write)
-- 0x20 : reserved
-- 0x24 : Data signal of length_r
--        bit 31~0 - length_r[31:0] (Read/Write)
-- 0x28 : reserved
-- 0x2c : Data signal of step_index
--        bit 31~0 - step_index[31:0] (Read/Write)
-- 0x30 : reserved
-- 0x34 : Data signal of threshold_q15
--        bit 31~0 - threshold_q15[31:0] (Read/Write)
-- 0x38 : reserved
-- 0x3c : Data signal of warmup_steps
--        bit 31~0 - warmup_steps[31:0] (Read/Write)
-- 0x40 : reserved
-- 0x44 : Data signal of max_consecutive_skips
--        bit 31~0 - max_consecutive_skips[31:0] (Read/Write)
-- 0x48 : reserved
-- 0x4c : Data signal of reset_state
--        bit 31~0 - reset_state[31:0] (Read/Write)
-- 0x50 : reserved
-- 0x54 : Data signal of dot_out
--        bit 31~0 - dot_out[31:0] (Read)
-- 0x58 : Data signal of dot_out
--        bit 31~0 - dot_out[63:32] (Read)
-- 0x5c : Control signal of dot_out
--        bit 0  - dot_out_ap_vld (Read/COR)
--        others - reserved
-- 0x6c : Data signal of norm_x_out
--        bit 31~0 - norm_x_out[31:0] (Read)
-- 0x70 : Data signal of norm_x_out
--        bit 31~0 - norm_x_out[63:32] (Read)
-- 0x74 : Control signal of norm_x_out
--        bit 0  - norm_x_out_ap_vld (Read/COR)
--        others - reserved
-- 0x84 : Data signal of norm_y_out
--        bit 31~0 - norm_y_out[31:0] (Read)
-- 0x88 : Data signal of norm_y_out
--        bit 31~0 - norm_y_out[63:32] (Read)
-- 0x8c : Control signal of norm_y_out
--        bit 0  - norm_y_out_ap_vld (Read/COR)
--        others - reserved
-- 0x9c : Data signal of threshold_passed_out
--        bit 31~0 - threshold_passed_out[31:0] (Read)
-- 0xa0 : Control signal of threshold_passed_out
--        bit 0  - threshold_passed_out_ap_vld (Read/COR)
--        others - reserved
-- 0xac : Data signal of skip_streak_out
--        bit 31~0 - skip_streak_out[31:0] (Read)
-- 0xb0 : Control signal of skip_streak_out
--        bit 0  - skip_streak_out_ap_vld (Read/COR)
--        others - reserved
-- (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

architecture behave of cosine_skip_control_s_axi is
    type states is (wridle, wrdata, wrresp, wrreset, rdidle, rddata, rdreset);  -- read and write fsm states
    signal wstate  : states := wrreset;
    signal rstate  : states := rdreset;
    signal wnext, rnext: states;
    constant ADDR_AP_CTRL                      : INTEGER := 16#00#;
    constant ADDR_GIE                          : INTEGER := 16#04#;
    constant ADDR_IER                          : INTEGER := 16#08#;
    constant ADDR_ISR                          : INTEGER := 16#0c#;
    constant ADDR_AP_RETURN_0                  : INTEGER := 16#10#;
    constant ADDR_X_DATA_0                     : INTEGER := 16#18#;
    constant ADDR_X_DATA_1                     : INTEGER := 16#1c#;
    constant ADDR_X_CTRL                       : INTEGER := 16#20#;
    constant ADDR_LENGTH_R_DATA_0              : INTEGER := 16#24#;
    constant ADDR_LENGTH_R_CTRL                : INTEGER := 16#28#;
    constant ADDR_STEP_INDEX_DATA_0            : INTEGER := 16#2c#;
    constant ADDR_STEP_INDEX_CTRL              : INTEGER := 16#30#;
    constant ADDR_THRESHOLD_Q15_DATA_0         : INTEGER := 16#34#;
    constant ADDR_THRESHOLD_Q15_CTRL           : INTEGER := 16#38#;
    constant ADDR_WARMUP_STEPS_DATA_0          : INTEGER := 16#3c#;
    constant ADDR_WARMUP_STEPS_CTRL            : INTEGER := 16#40#;
    constant ADDR_MAX_CONSECUTIVE_SKIPS_DATA_0 : INTEGER := 16#44#;
    constant ADDR_MAX_CONSECUTIVE_SKIPS_CTRL   : INTEGER := 16#48#;
    constant ADDR_RESET_STATE_DATA_0           : INTEGER := 16#4c#;
    constant ADDR_RESET_STATE_CTRL             : INTEGER := 16#50#;
    constant ADDR_DOT_OUT_DATA_0               : INTEGER := 16#54#;
    constant ADDR_DOT_OUT_DATA_1               : INTEGER := 16#58#;
    constant ADDR_DOT_OUT_CTRL                 : INTEGER := 16#5c#;
    constant ADDR_NORM_X_OUT_DATA_0            : INTEGER := 16#6c#;
    constant ADDR_NORM_X_OUT_DATA_1            : INTEGER := 16#70#;
    constant ADDR_NORM_X_OUT_CTRL              : INTEGER := 16#74#;
    constant ADDR_NORM_Y_OUT_DATA_0            : INTEGER := 16#84#;
    constant ADDR_NORM_Y_OUT_DATA_1            : INTEGER := 16#88#;
    constant ADDR_NORM_Y_OUT_CTRL              : INTEGER := 16#8c#;
    constant ADDR_THRESHOLD_PASSED_OUT_DATA_0  : INTEGER := 16#9c#;
    constant ADDR_THRESHOLD_PASSED_OUT_CTRL    : INTEGER := 16#a0#;
    constant ADDR_SKIP_STREAK_OUT_DATA_0       : INTEGER := 16#ac#;
    constant ADDR_SKIP_STREAK_OUT_CTRL         : INTEGER := 16#b0#;
    constant ADDR_BITS         : INTEGER := 8;

    signal waddr               : UNSIGNED(ADDR_BITS-1 downto 0);
    signal wmask               : UNSIGNED(C_S_AXI_DATA_WIDTH-1 downto 0);
    signal aw_hs               : STD_LOGIC;
    signal w_hs                : STD_LOGIC;
    signal rdata_data          : UNSIGNED(C_S_AXI_DATA_WIDTH-1 downto 0);
    signal ar_hs               : STD_LOGIC;
    signal raddr               : UNSIGNED(ADDR_BITS-1 downto 0);
    signal AWREADY_t           : STD_LOGIC;
    signal WREADY_t            : STD_LOGIC;
    signal ARREADY_t           : STD_LOGIC;
    signal RVALID_t            : STD_LOGIC;
    -- internal registers
    signal int_ap_idle         : STD_LOGIC := '0';
    signal int_ap_ready        : STD_LOGIC := '0';
    signal task_ap_ready       : STD_LOGIC;
    signal int_ap_done         : STD_LOGIC := '0';
    signal task_ap_done        : STD_LOGIC;
    signal int_task_ap_done    : STD_LOGIC := '0';
    signal int_ap_start        : STD_LOGIC := '0';
    signal int_interrupt       : STD_LOGIC := '0';
    signal int_auto_restart    : STD_LOGIC := '0';
    signal auto_restart_status : STD_LOGIC := '0';
    signal auto_restart_done   : STD_LOGIC;
    signal int_gie             : STD_LOGIC := '0';
    signal int_ier             : UNSIGNED(1 downto 0) := (others => '0');
    signal int_isr             : UNSIGNED(1 downto 0) := (others => '0');
    signal int_ap_return       : UNSIGNED(31 downto 0);
    signal int_x               : UNSIGNED(63 downto 0) := (others => '0');
    signal int_length_r        : UNSIGNED(31 downto 0) := (others => '0');
    signal int_step_index      : UNSIGNED(31 downto 0) := (others => '0');
    signal int_threshold_q15   : UNSIGNED(31 downto 0) := (others => '0');
    signal int_warmup_steps    : UNSIGNED(31 downto 0) := (others => '0');
    signal int_max_consecutive_skips : UNSIGNED(31 downto 0) := (others => '0');
    signal int_reset_state     : UNSIGNED(31 downto 0) := (others => '0');
    signal int_dot_out_ap_vld  : STD_LOGIC;
    signal int_dot_out         : UNSIGNED(63 downto 0) := (others => '0');
    signal int_norm_x_out_ap_vld : STD_LOGIC;
    signal int_norm_x_out      : UNSIGNED(63 downto 0) := (others => '0');
    signal int_norm_y_out_ap_vld : STD_LOGIC;
    signal int_norm_y_out      : UNSIGNED(63 downto 0) := (others => '0');
    signal int_threshold_passed_out_ap_vld : STD_LOGIC;
    signal int_threshold_passed_out : UNSIGNED(31 downto 0) := (others => '0');
    signal int_skip_streak_out_ap_vld : STD_LOGIC;
    signal int_skip_streak_out : UNSIGNED(31 downto 0) := (others => '0');


begin
-- ----------------------- Instantiation------------------


-- ----------------------- AXI WRITE ---------------------
    AWREADY_t <=  '1' when wstate = wridle else '0';
    AWREADY   <=  AWREADY_t;
    WREADY_t  <=  '1' when wstate = wrdata else '0';
    WREADY    <=  WREADY_t;
    BRESP     <=  "00";  -- OKAY
    BVALID    <=  '1' when wstate = wrresp else '0';
    wmask     <=  (31 downto 24 => WSTRB(3), 23 downto 16 => WSTRB(2), 15 downto 8 => WSTRB(1), 7 downto 0 => WSTRB(0));
    aw_hs     <=  AWVALID and AWREADY_t;
    w_hs      <=  WVALID and WREADY_t;

    -- write FSM
    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                wstate <= wrreset;
            elsif (ACLK_EN = '1') then
                wstate <= wnext;
            end if;
        end if;
    end process;

    process (wstate, AWVALID, WVALID, BREADY)
    begin
        case (wstate) is
        when wridle =>
            if (AWVALID = '1') then
                wnext <= wrdata;
            else
                wnext <= wridle;
            end if;
        when wrdata =>
            if (WVALID = '1') then
                wnext <= wrresp;
            else
                wnext <= wrdata;
            end if;
        when wrresp =>
            if (BREADY = '1') then
                wnext <= wridle;
            else
                wnext <= wrresp;
            end if;
        when others =>
            wnext <= wridle;
        end case;
    end process;

    waddr_proc : process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (aw_hs = '1') then
                    waddr <= UNSIGNED(AWADDR(ADDR_BITS-1 downto 0));
                end if;
            end if;
        end if;
    end process;

-- ----------------------- AXI READ ----------------------
    ARREADY_t <= '1' when (rstate = rdidle) else '0';
    ARREADY <= ARREADY_t;
    RDATA   <= STD_LOGIC_VECTOR(rdata_data);
    RRESP   <= "00";  -- OKAY
    RVALID_t  <= '1' when (rstate = rddata) else '0';
    RVALID    <= RVALID_t;
    ar_hs   <= ARVALID and ARREADY_t;
    raddr   <= UNSIGNED(ARADDR(ADDR_BITS-1 downto 0));

    -- read FSM
    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                rstate <= rdreset;
            elsif (ACLK_EN = '1') then
                rstate <= rnext;
            end if;
        end if;
    end process;

    process (rstate, ARVALID, RREADY, RVALID_t)
    begin
        case (rstate) is
        when rdidle =>
            if (ARVALID = '1') then
                rnext <= rddata;
            else
                rnext <= rdidle;
            end if;
        when rddata =>
            if (RREADY = '1' and RVALID_t = '1') then
                rnext <= rdidle;
            else
                rnext <= rddata;
            end if;
        when others =>
            rnext <= rdidle;
        end case;
    end process;

    rdata_proc : process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (ar_hs = '1') then
                    rdata_data <= (others => '0');
                    case (TO_INTEGER(raddr)) is
                    when ADDR_AP_CTRL =>
                        rdata_data(9) <= int_interrupt;
                        rdata_data(7) <= int_auto_restart;
                        rdata_data(3) <= int_ap_ready;
                        rdata_data(2) <= int_ap_idle;
                        rdata_data(1) <= int_task_ap_done;
                        rdata_data(0) <= int_ap_start;
                    when ADDR_GIE =>
                        rdata_data(0) <= int_gie;
                    when ADDR_IER =>
                        rdata_data(1 downto 0) <= int_ier;
                    when ADDR_ISR =>
                        rdata_data(1 downto 0) <= int_isr;
                    when ADDR_AP_RETURN_0 =>
                        rdata_data <= RESIZE(int_ap_return(31 downto 0), 32);
                    when ADDR_X_DATA_0 =>
                        rdata_data <= RESIZE(int_x(31 downto 0), 32);
                    when ADDR_X_DATA_1 =>
                        rdata_data <= RESIZE(int_x(63 downto 32), 32);
                    when ADDR_LENGTH_R_DATA_0 =>
                        rdata_data <= RESIZE(int_length_r(31 downto 0), 32);
                    when ADDR_STEP_INDEX_DATA_0 =>
                        rdata_data <= RESIZE(int_step_index(31 downto 0), 32);
                    when ADDR_THRESHOLD_Q15_DATA_0 =>
                        rdata_data <= RESIZE(int_threshold_q15(31 downto 0), 32);
                    when ADDR_WARMUP_STEPS_DATA_0 =>
                        rdata_data <= RESIZE(int_warmup_steps(31 downto 0), 32);
                    when ADDR_MAX_CONSECUTIVE_SKIPS_DATA_0 =>
                        rdata_data <= RESIZE(int_max_consecutive_skips(31 downto 0), 32);
                    when ADDR_RESET_STATE_DATA_0 =>
                        rdata_data <= RESIZE(int_reset_state(31 downto 0), 32);
                    when ADDR_DOT_OUT_DATA_0 =>
                        rdata_data <= RESIZE(int_dot_out(31 downto 0), 32);
                    when ADDR_DOT_OUT_DATA_1 =>
                        rdata_data <= RESIZE(int_dot_out(63 downto 32), 32);
                    when ADDR_DOT_OUT_CTRL =>
                        rdata_data(0) <= int_dot_out_ap_vld;
                    when ADDR_NORM_X_OUT_DATA_0 =>
                        rdata_data <= RESIZE(int_norm_x_out(31 downto 0), 32);
                    when ADDR_NORM_X_OUT_DATA_1 =>
                        rdata_data <= RESIZE(int_norm_x_out(63 downto 32), 32);
                    when ADDR_NORM_X_OUT_CTRL =>
                        rdata_data(0) <= int_norm_x_out_ap_vld;
                    when ADDR_NORM_Y_OUT_DATA_0 =>
                        rdata_data <= RESIZE(int_norm_y_out(31 downto 0), 32);
                    when ADDR_NORM_Y_OUT_DATA_1 =>
                        rdata_data <= RESIZE(int_norm_y_out(63 downto 32), 32);
                    when ADDR_NORM_Y_OUT_CTRL =>
                        rdata_data(0) <= int_norm_y_out_ap_vld;
                    when ADDR_THRESHOLD_PASSED_OUT_DATA_0 =>
                        rdata_data <= RESIZE(int_threshold_passed_out(31 downto 0), 32);
                    when ADDR_THRESHOLD_PASSED_OUT_CTRL =>
                        rdata_data(0) <= int_threshold_passed_out_ap_vld;
                    when ADDR_SKIP_STREAK_OUT_DATA_0 =>
                        rdata_data <= RESIZE(int_skip_streak_out(31 downto 0), 32);
                    when ADDR_SKIP_STREAK_OUT_CTRL =>
                        rdata_data(0) <= int_skip_streak_out_ap_vld;
                    when others =>
                        NULL;
                    end case;
                end if;
            end if;
        end if;
    end process;

-- ----------------------- Register logic ----------------
    interrupt            <= int_interrupt;
    ap_start             <= int_ap_start;
    task_ap_done         <= (ap_done and not auto_restart_status) or auto_restart_done;
    task_ap_ready        <= ap_ready and not int_auto_restart;
    auto_restart_done    <= auto_restart_status and (ap_idle and not int_ap_idle);
    x                    <= STD_LOGIC_VECTOR(int_x);
    length_r             <= STD_LOGIC_VECTOR(int_length_r);
    step_index           <= STD_LOGIC_VECTOR(int_step_index);
    threshold_q15        <= STD_LOGIC_VECTOR(int_threshold_q15);
    warmup_steps         <= STD_LOGIC_VECTOR(int_warmup_steps);
    max_consecutive_skips <= STD_LOGIC_VECTOR(int_max_consecutive_skips);
    reset_state          <= STD_LOGIC_VECTOR(int_reset_state);

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_interrupt <= '0';
            elsif (ACLK_EN = '1') then
                if (int_gie = '1' and (int_isr(0) or int_isr(1)) = '1') then
                    int_interrupt <= '1';
                else
                    int_interrupt <= '0';
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_start <= '0';
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AP_CTRL and WSTRB(0) = '1' and WDATA(0) = '1') then
                    int_ap_start <= '1';
                elsif (ap_ready = '1') then
                    int_ap_start <= int_auto_restart; -- clear on handshake/auto restart
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_done <= '0';
            elsif (ACLK_EN = '1') then
                if (true) then
                    int_ap_done <= ap_done;
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_task_ap_done <= '0';
            elsif (ACLK_EN = '1') then
                if (task_ap_done = '1') then
                    int_task_ap_done <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_AP_CTRL) then
                    int_task_ap_done <= '0'; -- clear on read
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_idle <= '0';
            elsif (ACLK_EN = '1') then
                if (true) then
                    int_ap_idle <= ap_idle;
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_ready <= '0';
            elsif (ACLK_EN = '1') then
                if (task_ap_ready = '1') then
                    int_ap_ready <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_AP_CTRL) then
                    int_ap_ready <= '0';
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_auto_restart <= '0';
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AP_CTRL and WSTRB(0) = '1') then
                    int_auto_restart <= WDATA(7);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                auto_restart_status <= '0';
            elsif (ACLK_EN = '1') then
                if (int_auto_restart = '1') then
                    auto_restart_status <= '1';
                elsif (ap_idle = '1') then
                    auto_restart_status <= '0';
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_gie <= '0';
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_GIE and WSTRB(0) = '1') then
                    int_gie <= WDATA(0);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ier <= (others=>'0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_IER and WSTRB(0) = '1') then
                    int_ier <= UNSIGNED(WDATA(1 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_isr(0) <= '0';
            elsif (ACLK_EN = '1') then
                if (int_ier(0) = '1' and ap_done = '1') then
                    int_isr(0) <= '1';
                elsif (w_hs = '1' and waddr = ADDR_ISR and WSTRB(0) = '1') then
                    int_isr(0) <= int_isr(0) xor WDATA(0); -- toggle on write
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_isr(1) <= '0';
            elsif (ACLK_EN = '1') then
                if (int_ier(1) = '1' and ap_ready = '1') then
                    int_isr(1) <= '1';
                elsif (w_hs = '1' and waddr = ADDR_ISR and WSTRB(0) = '1') then
                    int_isr(1) <= int_isr(1) xor WDATA(1); -- toggle on write
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_return <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (ap_done = '1') then
                    int_ap_return <= UNSIGNED(ap_return);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_X_DATA_0) then
                    int_x(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_x(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_X_DATA_1) then
                    int_x(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_x(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_LENGTH_R_DATA_0) then
                    int_length_r(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_length_r(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_STEP_INDEX_DATA_0) then
                    int_step_index(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_step_index(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_THRESHOLD_Q15_DATA_0) then
                    int_threshold_q15(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_threshold_q15(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_WARMUP_STEPS_DATA_0) then
                    int_warmup_steps(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_warmup_steps(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_MAX_CONSECUTIVE_SKIPS_DATA_0) then
                    int_max_consecutive_skips(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_max_consecutive_skips(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_RESET_STATE_DATA_0) then
                    int_reset_state(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_reset_state(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_dot_out <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (dot_out_ap_vld = '1') then
                    int_dot_out <= UNSIGNED(dot_out);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_dot_out_ap_vld <= '0';
            elsif (ACLK_EN = '1') then
                if (dot_out_ap_vld = '1') then
                    int_dot_out_ap_vld <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_DOT_OUT_CTRL) then
                    int_dot_out_ap_vld <= '0'; -- clear on read
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_norm_x_out <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (norm_x_out_ap_vld = '1') then
                    int_norm_x_out <= UNSIGNED(norm_x_out);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_norm_x_out_ap_vld <= '0';
            elsif (ACLK_EN = '1') then
                if (norm_x_out_ap_vld = '1') then
                    int_norm_x_out_ap_vld <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_NORM_X_OUT_CTRL) then
                    int_norm_x_out_ap_vld <= '0'; -- clear on read
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_norm_y_out <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (norm_y_out_ap_vld = '1') then
                    int_norm_y_out <= UNSIGNED(norm_y_out);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_norm_y_out_ap_vld <= '0';
            elsif (ACLK_EN = '1') then
                if (norm_y_out_ap_vld = '1') then
                    int_norm_y_out_ap_vld <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_NORM_Y_OUT_CTRL) then
                    int_norm_y_out_ap_vld <= '0'; -- clear on read
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_threshold_passed_out <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (threshold_passed_out_ap_vld = '1') then
                    int_threshold_passed_out <= UNSIGNED(threshold_passed_out);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_threshold_passed_out_ap_vld <= '0';
            elsif (ACLK_EN = '1') then
                if (threshold_passed_out_ap_vld = '1') then
                    int_threshold_passed_out_ap_vld <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_THRESHOLD_PASSED_OUT_CTRL) then
                    int_threshold_passed_out_ap_vld <= '0'; -- clear on read
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_skip_streak_out <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (skip_streak_out_ap_vld = '1') then
                    int_skip_streak_out <= UNSIGNED(skip_streak_out);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_skip_streak_out_ap_vld <= '0';
            elsif (ACLK_EN = '1') then
                if (skip_streak_out_ap_vld = '1') then
                    int_skip_streak_out_ap_vld <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_SKIP_STREAK_OUT_CTRL) then
                    int_skip_streak_out_ap_vld <= '0'; -- clear on read
                end if;
            end if;
        end if;
    end process;


-- ----------------------- Memory logic ------------------

end architecture behave;
