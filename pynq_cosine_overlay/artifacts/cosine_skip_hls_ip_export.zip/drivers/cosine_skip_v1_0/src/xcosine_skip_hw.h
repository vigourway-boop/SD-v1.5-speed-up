// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of ap_return
//        bit 31~0 - ap_return[31:0] (Read)
// 0x18 : Data signal of x
//        bit 31~0 - x[31:0] (Read/Write)
// 0x1c : Data signal of x
//        bit 31~0 - x[63:32] (Read/Write)
// 0x20 : reserved
// 0x24 : Data signal of length_r
//        bit 31~0 - length_r[31:0] (Read/Write)
// 0x28 : reserved
// 0x2c : Data signal of step_index
//        bit 31~0 - step_index[31:0] (Read/Write)
// 0x30 : reserved
// 0x34 : Data signal of threshold_q15
//        bit 31~0 - threshold_q15[31:0] (Read/Write)
// 0x38 : reserved
// 0x3c : Data signal of warmup_steps
//        bit 31~0 - warmup_steps[31:0] (Read/Write)
// 0x40 : reserved
// 0x44 : Data signal of max_consecutive_skips
//        bit 31~0 - max_consecutive_skips[31:0] (Read/Write)
// 0x48 : reserved
// 0x4c : Data signal of reset_state
//        bit 31~0 - reset_state[31:0] (Read/Write)
// 0x50 : reserved
// 0x54 : Data signal of dot_out
//        bit 31~0 - dot_out[31:0] (Read)
// 0x58 : Data signal of dot_out
//        bit 31~0 - dot_out[63:32] (Read)
// 0x5c : Control signal of dot_out
//        bit 0  - dot_out_ap_vld (Read/COR)
//        others - reserved
// 0x6c : Data signal of norm_x_out
//        bit 31~0 - norm_x_out[31:0] (Read)
// 0x70 : Data signal of norm_x_out
//        bit 31~0 - norm_x_out[63:32] (Read)
// 0x74 : Control signal of norm_x_out
//        bit 0  - norm_x_out_ap_vld (Read/COR)
//        others - reserved
// 0x84 : Data signal of norm_y_out
//        bit 31~0 - norm_y_out[31:0] (Read)
// 0x88 : Data signal of norm_y_out
//        bit 31~0 - norm_y_out[63:32] (Read)
// 0x8c : Control signal of norm_y_out
//        bit 0  - norm_y_out_ap_vld (Read/COR)
//        others - reserved
// 0x9c : Data signal of threshold_passed_out
//        bit 31~0 - threshold_passed_out[31:0] (Read)
// 0xa0 : Control signal of threshold_passed_out
//        bit 0  - threshold_passed_out_ap_vld (Read/COR)
//        others - reserved
// 0xac : Data signal of skip_streak_out
//        bit 31~0 - skip_streak_out[31:0] (Read)
// 0xb0 : Control signal of skip_streak_out
//        bit 0  - skip_streak_out_ap_vld (Read/COR)
//        others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XCOSINE_SKIP_CONTROL_ADDR_AP_CTRL                    0x00
#define XCOSINE_SKIP_CONTROL_ADDR_GIE                        0x04
#define XCOSINE_SKIP_CONTROL_ADDR_IER                        0x08
#define XCOSINE_SKIP_CONTROL_ADDR_ISR                        0x0c
#define XCOSINE_SKIP_CONTROL_ADDR_AP_RETURN                  0x10
#define XCOSINE_SKIP_CONTROL_BITS_AP_RETURN                  32
#define XCOSINE_SKIP_CONTROL_ADDR_X_DATA                     0x18
#define XCOSINE_SKIP_CONTROL_BITS_X_DATA                     64
#define XCOSINE_SKIP_CONTROL_ADDR_LENGTH_R_DATA              0x24
#define XCOSINE_SKIP_CONTROL_BITS_LENGTH_R_DATA              32
#define XCOSINE_SKIP_CONTROL_ADDR_STEP_INDEX_DATA            0x2c
#define XCOSINE_SKIP_CONTROL_BITS_STEP_INDEX_DATA            32
#define XCOSINE_SKIP_CONTROL_ADDR_THRESHOLD_Q15_DATA         0x34
#define XCOSINE_SKIP_CONTROL_BITS_THRESHOLD_Q15_DATA         32
#define XCOSINE_SKIP_CONTROL_ADDR_WARMUP_STEPS_DATA          0x3c
#define XCOSINE_SKIP_CONTROL_BITS_WARMUP_STEPS_DATA          32
#define XCOSINE_SKIP_CONTROL_ADDR_MAX_CONSECUTIVE_SKIPS_DATA 0x44
#define XCOSINE_SKIP_CONTROL_BITS_MAX_CONSECUTIVE_SKIPS_DATA 32
#define XCOSINE_SKIP_CONTROL_ADDR_RESET_STATE_DATA           0x4c
#define XCOSINE_SKIP_CONTROL_BITS_RESET_STATE_DATA           32
#define XCOSINE_SKIP_CONTROL_ADDR_DOT_OUT_DATA               0x54
#define XCOSINE_SKIP_CONTROL_BITS_DOT_OUT_DATA               64
#define XCOSINE_SKIP_CONTROL_ADDR_DOT_OUT_CTRL               0x5c
#define XCOSINE_SKIP_CONTROL_ADDR_NORM_X_OUT_DATA            0x6c
#define XCOSINE_SKIP_CONTROL_BITS_NORM_X_OUT_DATA            64
#define XCOSINE_SKIP_CONTROL_ADDR_NORM_X_OUT_CTRL            0x74
#define XCOSINE_SKIP_CONTROL_ADDR_NORM_Y_OUT_DATA            0x84
#define XCOSINE_SKIP_CONTROL_BITS_NORM_Y_OUT_DATA            64
#define XCOSINE_SKIP_CONTROL_ADDR_NORM_Y_OUT_CTRL            0x8c
#define XCOSINE_SKIP_CONTROL_ADDR_THRESHOLD_PASSED_OUT_DATA  0x9c
#define XCOSINE_SKIP_CONTROL_BITS_THRESHOLD_PASSED_OUT_DATA  32
#define XCOSINE_SKIP_CONTROL_ADDR_THRESHOLD_PASSED_OUT_CTRL  0xa0
#define XCOSINE_SKIP_CONTROL_ADDR_SKIP_STREAK_OUT_DATA       0xac
#define XCOSINE_SKIP_CONTROL_BITS_SKIP_STREAK_OUT_DATA       32
#define XCOSINE_SKIP_CONTROL_ADDR_SKIP_STREAK_OUT_CTRL       0xb0

