// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of ap_return
//        bit 31~0 - ap_return[31:0] (Read)
// 0x18 : Data signal of x
//        bit 31~0 - x[31:0] (Read/Write)
// 0x1c : Data signal of x
//        bit 31~0 - x[63:32] (Read/Write)
// 0x20 : reserved
// 0x24 : Data signal of y
//        bit 31~0 - y[31:0] (Read/Write)
// 0x28 : Data signal of y
//        bit 31~0 - y[63:32] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of length_r
//        bit 31~0 - length_r[31:0] (Read/Write)
// 0x34 : reserved
// 0x38 : Data signal of threshold_q15
//        bit 31~0 - threshold_q15[31:0] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of dot_out
//        bit 31~0 - dot_out[31:0] (Read)
// 0x44 : Data signal of dot_out
//        bit 31~0 - dot_out[63:32] (Read)
// 0x48 : Control signal of dot_out
//        bit 0  - dot_out_ap_vld (Read/COR)
//        others - reserved
// 0x58 : Data signal of norm_x_out
//        bit 31~0 - norm_x_out[31:0] (Read)
// 0x5c : Data signal of norm_x_out
//        bit 31~0 - norm_x_out[63:32] (Read)
// 0x60 : Control signal of norm_x_out
//        bit 0  - norm_x_out_ap_vld (Read/COR)
//        others - reserved
// 0x70 : Data signal of norm_y_out
//        bit 31~0 - norm_y_out[31:0] (Read)
// 0x74 : Data signal of norm_y_out
//        bit 31~0 - norm_y_out[63:32] (Read)
// 0x78 : Control signal of norm_y_out
//        bit 0  - norm_y_out_ap_vld (Read/COR)
//        others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XCOSINE_SKIP_CONTROL_ADDR_AP_CTRL            0x00
#define XCOSINE_SKIP_CONTROL_ADDR_GIE                0x04
#define XCOSINE_SKIP_CONTROL_ADDR_IER                0x08
#define XCOSINE_SKIP_CONTROL_ADDR_ISR                0x0c
#define XCOSINE_SKIP_CONTROL_ADDR_AP_RETURN          0x10
#define XCOSINE_SKIP_CONTROL_BITS_AP_RETURN          32
#define XCOSINE_SKIP_CONTROL_ADDR_X_DATA             0x18
#define XCOSINE_SKIP_CONTROL_BITS_X_DATA             64
#define XCOSINE_SKIP_CONTROL_ADDR_Y_DATA             0x24
#define XCOSINE_SKIP_CONTROL_BITS_Y_DATA             64
#define XCOSINE_SKIP_CONTROL_ADDR_LENGTH_R_DATA      0x30
#define XCOSINE_SKIP_CONTROL_BITS_LENGTH_R_DATA      32
#define XCOSINE_SKIP_CONTROL_ADDR_THRESHOLD_Q15_DATA 0x38
#define XCOSINE_SKIP_CONTROL_BITS_THRESHOLD_Q15_DATA 32
#define XCOSINE_SKIP_CONTROL_ADDR_DOT_OUT_DATA       0x40
#define XCOSINE_SKIP_CONTROL_BITS_DOT_OUT_DATA       64
#define XCOSINE_SKIP_CONTROL_ADDR_DOT_OUT_CTRL       0x48
#define XCOSINE_SKIP_CONTROL_ADDR_NORM_X_OUT_DATA    0x58
#define XCOSINE_SKIP_CONTROL_BITS_NORM_X_OUT_DATA    64
#define XCOSINE_SKIP_CONTROL_ADDR_NORM_X_OUT_CTRL    0x60
#define XCOSINE_SKIP_CONTROL_ADDR_NORM_Y_OUT_DATA    0x70
#define XCOSINE_SKIP_CONTROL_BITS_NORM_Y_OUT_DATA    64
#define XCOSINE_SKIP_CONTROL_ADDR_NORM_Y_OUT_CTRL    0x78

