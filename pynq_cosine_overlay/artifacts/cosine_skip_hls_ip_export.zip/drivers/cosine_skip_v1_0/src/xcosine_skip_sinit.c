// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xcosine_skip.h"

extern XCosine_skip_Config XCosine_skip_ConfigTable[];

XCosine_skip_Config *XCosine_skip_LookupConfig(u16 DeviceId) {
	XCosine_skip_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XCOSINE_SKIP_NUM_INSTANCES; Index++) {
		if (XCosine_skip_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XCosine_skip_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XCosine_skip_Initialize(XCosine_skip *InstancePtr, u16 DeviceId) {
	XCosine_skip_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XCosine_skip_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XCosine_skip_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

