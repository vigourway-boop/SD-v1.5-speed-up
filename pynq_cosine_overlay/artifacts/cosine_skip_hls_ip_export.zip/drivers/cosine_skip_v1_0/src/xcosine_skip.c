// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xcosine_skip.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XCosine_skip_CfgInitialize(XCosine_skip *InstancePtr, XCosine_skip_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XCosine_skip_Start(XCosine_skip *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_AP_CTRL) & 0x80;
    XCosine_skip_WriteReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XCosine_skip_IsDone(XCosine_skip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XCosine_skip_IsIdle(XCosine_skip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XCosine_skip_IsReady(XCosine_skip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XCosine_skip_EnableAutoRestart(XCosine_skip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCosine_skip_WriteReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XCosine_skip_DisableAutoRestart(XCosine_skip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCosine_skip_WriteReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_AP_CTRL, 0);
}

u32 XCosine_skip_Get_return(XCosine_skip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_AP_RETURN);
    return Data;
}
void XCosine_skip_Set_x(XCosine_skip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCosine_skip_WriteReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_X_DATA, (u32)(Data));
    XCosine_skip_WriteReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_X_DATA + 4, (u32)(Data >> 32));
}

u64 XCosine_skip_Get_x(XCosine_skip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_X_DATA);
    Data += (u64)XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_X_DATA + 4) << 32;
    return Data;
}

void XCosine_skip_Set_length_r(XCosine_skip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCosine_skip_WriteReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_LENGTH_R_DATA, Data);
}

u32 XCosine_skip_Get_length_r(XCosine_skip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_LENGTH_R_DATA);
    return Data;
}

void XCosine_skip_Set_step_index(XCosine_skip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCosine_skip_WriteReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_STEP_INDEX_DATA, Data);
}

u32 XCosine_skip_Get_step_index(XCosine_skip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_STEP_INDEX_DATA);
    return Data;
}

void XCosine_skip_Set_threshold_q15(XCosine_skip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCosine_skip_WriteReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_THRESHOLD_Q15_DATA, Data);
}

u32 XCosine_skip_Get_threshold_q15(XCosine_skip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_THRESHOLD_Q15_DATA);
    return Data;
}

void XCosine_skip_Set_warmup_steps(XCosine_skip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCosine_skip_WriteReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_WARMUP_STEPS_DATA, Data);
}

u32 XCosine_skip_Get_warmup_steps(XCosine_skip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_WARMUP_STEPS_DATA);
    return Data;
}

void XCosine_skip_Set_max_consecutive_skips(XCosine_skip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCosine_skip_WriteReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_MAX_CONSECUTIVE_SKIPS_DATA, Data);
}

u32 XCosine_skip_Get_max_consecutive_skips(XCosine_skip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_MAX_CONSECUTIVE_SKIPS_DATA);
    return Data;
}

void XCosine_skip_Set_reset_state(XCosine_skip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCosine_skip_WriteReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_RESET_STATE_DATA, Data);
}

u32 XCosine_skip_Get_reset_state(XCosine_skip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_RESET_STATE_DATA);
    return Data;
}

u64 XCosine_skip_Get_dot_out(XCosine_skip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_DOT_OUT_DATA);
    Data += (u64)XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_DOT_OUT_DATA + 4) << 32;
    return Data;
}

u32 XCosine_skip_Get_dot_out_vld(XCosine_skip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_DOT_OUT_CTRL);
    return Data & 0x1;
}

u64 XCosine_skip_Get_norm_x_out(XCosine_skip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_NORM_X_OUT_DATA);
    Data += (u64)XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_NORM_X_OUT_DATA + 4) << 32;
    return Data;
}

u32 XCosine_skip_Get_norm_x_out_vld(XCosine_skip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_NORM_X_OUT_CTRL);
    return Data & 0x1;
}

u64 XCosine_skip_Get_norm_y_out(XCosine_skip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_NORM_Y_OUT_DATA);
    Data += (u64)XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_NORM_Y_OUT_DATA + 4) << 32;
    return Data;
}

u32 XCosine_skip_Get_norm_y_out_vld(XCosine_skip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_NORM_Y_OUT_CTRL);
    return Data & 0x1;
}

u32 XCosine_skip_Get_threshold_passed_out(XCosine_skip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_THRESHOLD_PASSED_OUT_DATA);
    return Data;
}

u32 XCosine_skip_Get_threshold_passed_out_vld(XCosine_skip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_THRESHOLD_PASSED_OUT_CTRL);
    return Data & 0x1;
}

u32 XCosine_skip_Get_skip_streak_out(XCosine_skip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_SKIP_STREAK_OUT_DATA);
    return Data;
}

u32 XCosine_skip_Get_skip_streak_out_vld(XCosine_skip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_SKIP_STREAK_OUT_CTRL);
    return Data & 0x1;
}

void XCosine_skip_InterruptGlobalEnable(XCosine_skip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCosine_skip_WriteReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_GIE, 1);
}

void XCosine_skip_InterruptGlobalDisable(XCosine_skip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCosine_skip_WriteReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_GIE, 0);
}

void XCosine_skip_InterruptEnable(XCosine_skip *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_IER);
    XCosine_skip_WriteReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_IER, Register | Mask);
}

void XCosine_skip_InterruptDisable(XCosine_skip *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_IER);
    XCosine_skip_WriteReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_IER, Register & (~Mask));
}

void XCosine_skip_InterruptClear(XCosine_skip *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCosine_skip_WriteReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_ISR, Mask);
}

u32 XCosine_skip_InterruptGetEnabled(XCosine_skip *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_IER);
}

u32 XCosine_skip_InterruptGetStatus(XCosine_skip *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XCosine_skip_ReadReg(InstancePtr->Control_BaseAddress, XCOSINE_SKIP_CONTROL_ADDR_ISR);
}

