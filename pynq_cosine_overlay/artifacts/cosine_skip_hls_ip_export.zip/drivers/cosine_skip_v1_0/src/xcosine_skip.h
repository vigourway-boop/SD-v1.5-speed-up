// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XCOSINE_SKIP_H
#define XCOSINE_SKIP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xcosine_skip_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
} XCosine_skip_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XCosine_skip;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XCosine_skip_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XCosine_skip_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XCosine_skip_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XCosine_skip_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XCosine_skip_Initialize(XCosine_skip *InstancePtr, u16 DeviceId);
XCosine_skip_Config* XCosine_skip_LookupConfig(u16 DeviceId);
int XCosine_skip_CfgInitialize(XCosine_skip *InstancePtr, XCosine_skip_Config *ConfigPtr);
#else
int XCosine_skip_Initialize(XCosine_skip *InstancePtr, const char* InstanceName);
int XCosine_skip_Release(XCosine_skip *InstancePtr);
#endif

void XCosine_skip_Start(XCosine_skip *InstancePtr);
u32 XCosine_skip_IsDone(XCosine_skip *InstancePtr);
u32 XCosine_skip_IsIdle(XCosine_skip *InstancePtr);
u32 XCosine_skip_IsReady(XCosine_skip *InstancePtr);
void XCosine_skip_EnableAutoRestart(XCosine_skip *InstancePtr);
void XCosine_skip_DisableAutoRestart(XCosine_skip *InstancePtr);
u32 XCosine_skip_Get_return(XCosine_skip *InstancePtr);

void XCosine_skip_Set_x(XCosine_skip *InstancePtr, u64 Data);
u64 XCosine_skip_Get_x(XCosine_skip *InstancePtr);
void XCosine_skip_Set_length_r(XCosine_skip *InstancePtr, u32 Data);
u32 XCosine_skip_Get_length_r(XCosine_skip *InstancePtr);
void XCosine_skip_Set_step_index(XCosine_skip *InstancePtr, u32 Data);
u32 XCosine_skip_Get_step_index(XCosine_skip *InstancePtr);
void XCosine_skip_Set_threshold_q15(XCosine_skip *InstancePtr, u32 Data);
u32 XCosine_skip_Get_threshold_q15(XCosine_skip *InstancePtr);
void XCosine_skip_Set_warmup_steps(XCosine_skip *InstancePtr, u32 Data);
u32 XCosine_skip_Get_warmup_steps(XCosine_skip *InstancePtr);
void XCosine_skip_Set_max_consecutive_skips(XCosine_skip *InstancePtr, u32 Data);
u32 XCosine_skip_Get_max_consecutive_skips(XCosine_skip *InstancePtr);
void XCosine_skip_Set_reset_state(XCosine_skip *InstancePtr, u32 Data);
u32 XCosine_skip_Get_reset_state(XCosine_skip *InstancePtr);
u64 XCosine_skip_Get_dot_out(XCosine_skip *InstancePtr);
u32 XCosine_skip_Get_dot_out_vld(XCosine_skip *InstancePtr);
u64 XCosine_skip_Get_norm_x_out(XCosine_skip *InstancePtr);
u32 XCosine_skip_Get_norm_x_out_vld(XCosine_skip *InstancePtr);
u64 XCosine_skip_Get_norm_y_out(XCosine_skip *InstancePtr);
u32 XCosine_skip_Get_norm_y_out_vld(XCosine_skip *InstancePtr);
u32 XCosine_skip_Get_threshold_passed_out(XCosine_skip *InstancePtr);
u32 XCosine_skip_Get_threshold_passed_out_vld(XCosine_skip *InstancePtr);
u32 XCosine_skip_Get_skip_streak_out(XCosine_skip *InstancePtr);
u32 XCosine_skip_Get_skip_streak_out_vld(XCosine_skip *InstancePtr);
void XCosine_skip_Set_distance_threshold_q20(XCosine_skip *InstancePtr, u32 Data);
u32 XCosine_skip_Get_distance_threshold_q20(XCosine_skip *InstancePtr);
u32 XCosine_skip_Get_distance_passed_out(XCosine_skip *InstancePtr);
u32 XCosine_skip_Get_distance_passed_out_vld(XCosine_skip *InstancePtr);

void XCosine_skip_InterruptGlobalEnable(XCosine_skip *InstancePtr);
void XCosine_skip_InterruptGlobalDisable(XCosine_skip *InstancePtr);
void XCosine_skip_InterruptEnable(XCosine_skip *InstancePtr, u32 Mask);
void XCosine_skip_InterruptDisable(XCosine_skip *InstancePtr, u32 Mask);
void XCosine_skip_InterruptClear(XCosine_skip *InstancePtr, u32 Mask);
u32 XCosine_skip_InterruptGetEnabled(XCosine_skip *InstancePtr);
u32 XCosine_skip_InterruptGetStatus(XCosine_skip *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
